# Manual Golden Gate Assembly Protocol

## Reaction Setup

- Total reaction volume: 20 uL
- DNA input volume: 2 uL per backbone or part
- Assemblies: 1

## Assembly 1: assembly_product_1

| Reagent | Volume (uL) |
| --- | ---: |
| Nuclease-free water | 2 |
| T4 DNA ligase buffer | 2 |
| T4 DNA ligase | 4 |
| BsaI restriction enzyme | 2 |
| dvk_backbone_core | 2 |
| J23100 | 2 |
| B0034 | 2 |
| E0040m_gfp | 2 |
| B0015 | 2 |

1. Add reagents to a PCR tube or thermocycler plate well in the order listed.
2. Mix gently by pipetting, then briefly spin down.
3. Run the thermocycler program below.

## Thermocycler Program

| Step | Temperature | Time | Cycles |
| --- | --- | --- | ---: |
| Digest | 37 C | 2 min | 25 |
| Ligate | 16 C | 5 min | 25 |
| Final digestion | 50 C | 5 min | 1 |
| Heat inactivation | 80 C | 10 min | 1 |
| Hold | 4 C | indefinite | 1 |
